#include <ros/ros.h>

#include <iostream>
#include <geometry_msgs/Pose2D.h>
#include <graphical_client/Pose2D_Array.h>
#include <math.h>

#define RATE 2

#define BAG_RADIUS 50.0f


/**
 * UTILS
 **/
template <class T> class List {
public:
	List() {}

	void add(const T& value) {
		m_list.push_back(value);
	}

	T getAt(const unsigned int& i) const {
		return m_list.at(i);
	}

	int indexOf(const T& value) const {
		for (int i = 0; i < m_list.size(); i++)
			if (m_list.at(i) == value)
				return i;
		return -1;
	}

	bool contains(const T& value) const {
		return indexOf(value) >= 0;
	}

	unsigned int length() const {
		return m_list.size();
	}

	void removeAt(const unsigned int& i) {
		m_list.erase(m_list.begin() + i);
	}

	void remove(const T& value) {
		removeAt(indexOf(value));
	}

	void replace(const unsigned int& i, const T& value) {
		m_list[i] = value;
	}

private:
	std::vector<T> m_list;
};




template <class T, class U> class Map {
public:
	Map() {}

	void set(const T& key, const U& value) {
		int i = m_keys.indexOf(key);
		if (i < 0) {
			m_keys.add(key);
			m_values.add(value);
		}
		else
			m_values.replace(i, value);
	}

	U get(const T& key) const {
		return m_values.getAt(m_keys.indexOf(key));
	}

	void remove(const T& key) {
		int i = m_keys.indexOf(key);
		if (i >= 0) {
			m_keys.removeAt(i);
			m_values.removeAt(i);
		}
	}

private:
	List<T> m_keys;
	List<U> m_values;
};





class Vector2i {
public:
	Vector2i(const int& x, const int& y) : x(x), y(y) {}
	Vector2i() : Vector2i(0, 0) {}

	friend bool operator==(const Vector2i& left, const Vector2i& right) {
		return left.x == right.x && left.y == right.y;
	}

public:
	int x;
	int y;
};



class Node {
public:
	Node(const Vector2i& value, const float& cost) : m_value(value), m_cost(cost) {}

	const Vector2i& getValue() const {
		return m_value;
	}

	const float& getCost() const {
		return m_cost;
	}

	void addNeighbor(const Node& neighbor) {
		m_neighbors.add(&neighbor);
	}

	const List<const Node*>& getNeighbors() const {
		return m_neighbors;
	}
	
	friend bool operator==(const Node& left, const Node& right) {
		return left.m_value == right.m_value && left.m_cost == right.m_cost;
	}

private:
	Vector2i m_value;
	float m_cost;
	List<const Node*> m_neighbors;
};






namespace A_Star {

	List<const Node*> rebuildPath(const Map<const Node*, const Node*>& cameFrom, const Node* current) {
		auto total_path = List<const Node*>();
		total_path.add(current);
		for (unsigned int i = 0; i < total_path.length(); i++) {
			total_path.add(cameFrom.get(current));
		}
		return total_path;
	}

	const Node* getLowestScoreNode(const List<const Node*>& nodes) {
		unsigned int min_index = 0;
		for (unsigned int i = 0; i < nodes.length(); i++)
			if (nodes.getAt(i)->getCost() < nodes.getAt(min_index)->getCost())
				min_index = i;
		return nodes.getAt(min_index);
	}

	float distance(const Node* start, const Node* goal) {
		const Vector2i& s = start->getValue();
		const Vector2i& g = goal->getValue();
		return sqrt(pow(g.x - s.x, 2) + pow(g.y - s.y, 2));
	}

	float heuristic(const Node* start, const Node* goal) {
		return distance(start, goal) + start->getCost();
	}

	List<const Node*> getPath(const List<const Node*>& nodes, const Node& start, const Node& goal) {
		// The set of nodes already evaluated
	    auto closed_set = List<const Node*>();

	    // The set of currently discovered nodes that are not evaluated yet.
	    // Initially, only the start node is known.
	    auto open_set = List<const Node*>();
	    open_set.add(&start);

	    // For each node, which node it can most efficiently be reached from.
	    // If a node can be reached from many nodes, cameFrom will eventually contain the
	    // most efficient previous step.
	    auto came_from = Map<const Node*, const Node*>();

	    // For each node, the cost of getting from the start node to that node.
	    auto g_score = Map<const Node*, float>();
	    const Node* current;
	    for (int i = 1; i < nodes.length(); i++) {
	    	current = nodes.getAt(i);
	    	g_score.set(current, distance(current, &start));
	    }
	    // The cost of going from start to start is zero.
	    g_score.set(&start, 0.0f);

	    // For each node, the total cost of getting from the start node to the goal
	    // by passing by that node. That value is partly known, partly heuristic.
	    auto f_score = Map<const Node*, float>();
	    for (unsigned int i = 1; i < nodes.length(); i++)
	    	f_score.set(nodes.getAt(i), 2 << 16);

	    // For the first node, that value is completely heuristic.
	    f_score.set(&start, heuristic(&start, &goal));

	    while (open_set.length()) {
	    	current = getLowestScoreNode(open_set);
	        if (current == &goal)
	            return rebuildPath(came_from, current);

	        open_set.remove(current);
	        closed_set.add(current);

	        auto neighbors = current->getNeighbors();
	        const Node* neighbor;
	        for(unsigned int i = 0; i < neighbors.length(); i++) {
	        	neighbor = neighbors.getAt(i);
	            if (closed_set.contains(neighbor))
	                continue;		// Ignore the neighbor which is already evaluated.

	            // The distance from start to a neighbor
	            float tentative_gScore = g_score.get(current) + distance(current, neighbor);

	            if (!open_set.contains(neighbor))	// Discover a new node
	                open_set.add(neighbor);
	            else if (tentative_gScore >= g_score.get(neighbor))
	                continue;

	            // This path is the best until now. Record it!
	            came_from.set(neighbor, current);
	            g_score.set(neighbor, tentative_gScore);
	            f_score.set(neighbor, tentative_gScore + heuristic(neighbor, &goal));
	        }
	    }
	}
}






/**
 * THE MAIN SCRIPT
 **/
geometry_msgs::Pose2D GOAL;

void getGoalPosition(const geometry_msgs::Pose2D& pose) {
	GOAL = pose;
}

// Our bags
List<geometry_msgs::Pose2D> BAGS;

char current_bag = 0;
void getBag(const geometry_msgs::Pose2D& pose) {
	if (BAGS.length() <= current_bag)
		BAGS.add(pose);
	if (current_bag > 9) {
		current_bag = -1;
	}
	current_bag++;
}

// Car position
geometry_msgs::Pose2D CAR;

void saveCarPosition(const geometry_msgs::Pose2D& pos) {
	CAR = pos;
}

bool isNodeInBag(const Vector2i& pos, const std::vector<geometry_msgs::Pose2D>& bags) {
	geometry_msgs::Pose2D pose;
	for (unsigned int i = 0; i < BAGS.length(); i++) {
		pose = BAGS.getAt(i);
		if (sqrt(pow(pose.x - pos.x, 2) + pow(pose.y - pos.x, 2)) <= BAG_RADIUS)
			return true;
	}
	return false;
}


/**
 * Gets the trajectory to the goal.
 **/
graphical_client::Pose2D_Array getTrajectory(const geometry_msgs::Pose2D& car, 
	const std::vector<geometry_msgs::Pose2D>& bags, const geometry_msgs::Pose2D& goal) {
	// The grid proportions
	auto pos1 = Vector2i(0, -2500);
	auto pos2 = Vector2i(3500, 2500);
	int x_size = 200;
	int y_size = 200;
	// Divides the grid
	auto grid = List<Node>();
	auto node = Node(pos1, 0.0f);
	float cost;
	Vector2i pos = Vector2i();
	// And create the grid
	for (int y = pos1.y; y < pos2.y; y += y_size)
		for (int x = pos1.x; x < pos2.x; x += x_size) {
			pos.x = x;
			pos.y = y;
			cost = isNodeInBag(pos, bags) ? 100.0f : 0.0f;
			node = Node(pos, cost);
			grid.add(node);
		}
	auto trajectory = graphical_client::Pose2D_Array();
	auto pose = geometry_msgs::Pose2D();
	return trajectory;
}


/**
 * With a given trajectory and position, it calculates the velocity.
 **/
geometry_msgs::Pose2D getVelocity(const geometry_msgs::Pose2D& car,
	const graphical_client::Pose2D_Array& trajectory, const geometry_msgs::Pose2D& goal) {
	return goal;
}

geometry_msgs::Pose2D getPosition(const geometry_msgs::Pose2D& velocity) {
	return velocity;
}


int main(int argc, char **argv)  {

	ros::init(argc, argv, "coche_node");
	ros::NodeHandle nh;
	ROS_INFO_STREAM("coche_node initialized");																																							
	ROS_INFO_STREAM(ros::this_node::getName());

	ros::Rate rate(RATE);

	// Bag subscribers
	std::vector<ros::Subscriber> bags_subscribers;
	ros::Subscriber sub;
	for (int i = 0; i < 10; i++) {
		sub = ros::Subscriber();
		sub = nh.subscribe("/b_r" + std::to_string(i), 1000, &getBag);
		bags_subscribers.push_back(sub);
	}
	// Sends position
	ros::Publisher car_position_pub = nh.advertise<geometry_msgs::Pose2D> ("/y_r0", 1);
	// Receives position
	ros::Subscriber car_position_sub = nh.subscribe("/y_r0", 1000, &saveCarPosition);
	// Receives goal
	ros::Subscriber goal_sub = nh.subscribe("/ball", 1000, &getGoalPosition);
	// Prints trajectory
	ros::Publisher trajectory_pub = nh.advertise<graphical_client::Pose2D_Array> ("/trajectory", 1);

	//std_msgs::Float32 msg;
	//float m;

	geometry_msgs::Pose2D velocity;
	geometry_msgs::Pose2D position;
	graphical_client::Pose2D_Array trajectory;

	while (ros::ok())
	{
		ros::spinOnce();
		rate.sleep();

		if (bags.size() < 10) continue;

		// Gets the trajectory
		trajectory = getTrajectory(CAR, BAGS, GOAL);
		// Moves the car
		velocity = getVelocity(CAR, trajectory, GOAL);
		// Sets new position (only for testing)
		position = getPosition(velocity);
		//car_position_pub.publish(position);
		// Prints the trajectory
		trajectory_pub.publish(trajectory);
	}

    return 0;
}