#include <ros/ros.h>

#include <iostream>
#include <geometry_msgs/Pose2D.h>
#include <graphical_client/Pose2D_Array.h>

/**
*	source devel/setup.bash

**/

int main(int argc, char **argv)  {

	ros::init(argc,argv,"coche_node");
	ros::NodeHandle nh;
	ROS_INFO_STREAM("coche_node initialized");																																							
	ROS_INFO_STREAM(ros::this_node::getName());


	ros::Publisher force_pub = nh.advertise<geometry_msgs::Pose2D> ("/force_msg", 1);
	ros::Publisher trajectory_pub = nh.advertise<graphical_client::Pose2D_Array> ("/trajectory_msg", 1);

	//std_msgs::Float32 msg;
	float m;

	while (ros::ok())
	{
		//std::cout << "Introduce algo:" << std::endl;
		//std::cin >> m;

		//msg.data = m;
		//speed_pub.publish(msg);
	}

    return 0;
}
