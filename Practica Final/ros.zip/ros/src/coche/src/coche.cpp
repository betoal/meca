#include <ros/ros.h>

#include <iostream>
#include <geometry_msgs/Pose2D.h>
#include <graphical_client/Pose2D_Array.h>
#include <math.h>

#define RATE 4

#define BAG_RADIUS 50.0f


/**
 * UTILS
 **/
template <class T> class List {
public:
	List() {}

	~List() {
		clear();
	}

	void add(const T& value) {
		m_list.push_back(value);
	}

	T getAt(const unsigned int& i) const {
		return m_list.at(i);
	}

	int indexOf(const T& value) const {
		for (int i = 0; i < m_list.size(); i++)
			if (m_list.at(i) == value)
				return i;
		return -1;
	}

	bool contains(const T& value) const {
		return indexOf(value) >= 0;
	}

	unsigned int length() const {
		return m_list.size();
	}

	void removeAt(const unsigned int& i) {
		m_list.erase(m_list.begin() + i);
	}

	void remove(const T& value) {
		removeAt(indexOf(value));
	}

	void clear() {
		for (unsigned int i = 0; i < length(); i++)
			removeAt(i);
	}

	void replace(const unsigned int& i, const T& value) {
		m_list[i] = value;
	}

private:
	std::vector<T> m_list;
};




template <class T, class U> class Map {
public:
	Map() {}

	unsigned int length() const {
		return m_keys.length();
	}

	void set(const T& key, const U& value) {
		int i = m_keys.indexOf(key);
		if (i < 0) {
			m_keys.add(key);
			m_values.add(value);
		}
		else
			m_values.replace(i, value);
	}

	U get(const T& key) const {
		return m_values.getAt(m_keys.indexOf(key));
	}

	T getKey(const unsigned int& i) const {
		return m_keys.getAt(i);
	}

	U getValue(const unsigned int& i) const {
		return m_values.getAt(i);
	}

	void remove(const T& key) {
		int i = m_keys.indexOf(key);
		if (i >= 0) {
			m_keys.removeAt(i);
			m_values.removeAt(i);
		}
	}

private:
	List<T> m_keys;
	List<U> m_values;
};





class Vector2i {
public:
	Vector2i(const int& x, const int& y) : x(x), y(y) {}
	Vector2i() : Vector2i(0, 0) {}

	float getDistance(const Vector2i& other) const {
		return sqrt(pow(x - other.x, 2) + pow(y - other.y, 2));
	}

	geometry_msgs::Pose2D toPose2D() const {
		geometry_msgs::Pose2D res;
		res.x = x;
		res.y = y;
		res.theta = 0.0f;
		return res;
	}

	friend bool operator==(const Vector2i& left, const Vector2i& right) {
		return left.x == right.x && left.y == right.y;
	}

public:
	int x;
	int y;
};



class Node {
public:
	Node() : Node(Vector2i(), 0.0f) {}
	Node(const Vector2i& position, const float& cost) : m_position(position), m_cost(cost) {}

	const Vector2i& getPosition() const {
		return m_position;
	}

	const float& getCost() const {
		return m_cost;
	}

	void addNeighbor(Node* neighbor) {
		m_neighbors.add(neighbor);
	}

	float getDistance(const Node& other) const {
		return m_position.getDistance(other.getPosition());
	}

	const List<Node*>& getNeighbors() const {
		return m_neighbors;
	}
	
	friend bool operator==(const Node& left, const Node& right) {
		return left.m_position == right.m_position && left.m_cost == right.m_cost;
	}

private:
	Vector2i m_position;
	float m_cost;
	List<Node*> m_neighbors;
};






namespace A_Star {

	List<Node*> rebuildPath(const Map<Node*, Node*>& cameFrom, Node* current) {
		auto total_path = List<Node*>();
		total_path.add(current);
		for (unsigned int i = 0; i < cameFrom.length(); i++) {
			current = cameFrom.getKey(i);
			current = cameFrom.get(current);
			total_path.add(current);
		}
		return total_path;
	}

	Node* getLowestScoreNode(const Map<Node*, float>& fScore) {
		unsigned int min_index = 0;
		std::cout << "start" << std::endl;
		for (unsigned int i = 0; i < fScore.length(); i++)
			if (fScore.getValue(i) < fScore.getValue(min_index)) {
				std::cout << fScore.getValue(i) << std::endl;
				min_index = i;
			}
		std::cout << "end" << std::endl;
		return fScore.getKey(min_index);
	}

	float heuristic(Node* start, Node* goal) {
		return start->getDistance(*goal) + start->getCost();
	}

	List<Node*> getPath(const List<Node*>& nodes, Node& start, Node& goal) {
		// The set of nodes already evaluated
	    auto closed_set = List<Node*>();

	    // The set of currently discovered nodes that are not evaluated yet.
	    // Initially, only the start node is known.
	    auto open_set = List<Node*>();
	    open_set.add(&start);

	    // For each node, which node it can most efficiently be reached from.
	    // If a node can be reached from many nodes, cameFrom will eventually contain the
	    // most efficient previous step.
	    auto came_from = Map<Node*, Node*>();

	    // For each node, the cost of getting from the start node to that node.
	    auto g_score = Map<Node*, float>();

	    Node* current;
	    for (int i = 1; i < nodes.length(); i++) {
	    	current = nodes.getAt(i);
	    	g_score.set(current, current->getDistance(start));
	    }
	    // The cost of going from start to start is zero.
	    g_score.set(&start, 0.0f);

	    // For each node, the total cost of getting from the start node to the goal
	    // by passing by that node. That value is partly known, partly heuristic.
	    auto f_score = Map<Node*, float>();
	    for (unsigned int i = 1; i < nodes.length(); i++)
	    	f_score.set(nodes.getAt(i), 2 << 16);

	    // For the first node, that value is completely heuristic.
	    f_score.set(&start, heuristic(&start, &goal));

	    while (open_set.length()) {
	    	current = getLowestScoreNode(f_score);
	        if (current == &goal)
	            return rebuildPath(came_from, current);
	        std::cout << "asdfas" << std::endl;
	        open_set.remove(current);
	        std::cout << "removed" << std::endl;
	        closed_set.add(current);
	        std::cout << "added" << std::endl;

	        auto neighbors = current->getNeighbors();
	        std::cout << "hasfasdf" << std::endl;
	        Node* neighbor;
	        for(unsigned int i = 0; i < neighbors.length(); i++) {
	        	neighbor = neighbors.getAt(i);
	            if (closed_set.contains(neighbor))
	                continue;		// Ignore the neighbor which is already evaluated.

	            // The distance from start to a neighbor
	            float tentative_gScore = g_score.get(current) + current->getDistance(*neighbor);

	            if (!open_set.contains(neighbor))	// Discover a new node
	                open_set.add(neighbor);
	            else if (tentative_gScore >= g_score.get(neighbor))
	                continue;

	            // This path is the best until now. Record it!
	            came_from.set(neighbor, current);
	            g_score.set(neighbor, tentative_gScore);
	            f_score.set(neighbor, tentative_gScore + heuristic(neighbor, &goal));
	        }
	    }
	}
}






/**
 * THE MAIN SCRIPT
 **/

// The goal position
geometry_msgs::Pose2D GOAL;

void getGoalPosition(const geometry_msgs::Pose2D& pose) {
	GOAL = pose;
}

// Our bags
List<geometry_msgs::Pose2D> BAGS;

// Just gets the bags once
char current_bag = 0;
void getBag(const geometry_msgs::Pose2D& pose) {
	if (BAGS.length() <= current_bag)
		BAGS.add(pose);
	if (current_bag > 9) {
		current_bag = -1;
	}
	current_bag++;
}

// Car position
geometry_msgs::Pose2D CAR;

void saveCarPosition(const geometry_msgs::Pose2D& pos) {
	CAR = pos;
}

/**
 * Checks if a node is touching a bag.
 **/
bool isNodeInBag(const Vector2i& pos, const List<geometry_msgs::Pose2D>& bags, const float& radius) {
	geometry_msgs::Pose2D pose;
	for (unsigned int i = 0; i < BAGS.length(); i++) {
		pose = BAGS.getAt(i);
		if (sqrt(pow(pose.x - pos.x, 2) + pow(pose.y - pos.x, 2)) <= radius)
			return true;
	}
	return false;
}

/**
 * Creates the public grid.
**/
List<Node*> createGrid(const List<geometry_msgs::Pose2D>& bags, const Vector2i& pos1,
	const Vector2i& pos2, const int& x_size, const int& y_size) {
	// And create the grid
	auto grid = List<Node*>();
	auto pos = Vector2i();
	Node* node;
	float cost;
	for (int y = pos1.y; y < pos2.y; y += y_size)
		for (int x = pos1.x; x < pos2.x; x += x_size) {
			pos.x = x;
			pos.y = y;
			cost = isNodeInBag(pos, bags, BAG_RADIUS) ? 100.0f : 0.0f;
			node = new Node(pos, cost);
			grid.add(node);
		}
	int height = (pos2.y - pos1.y) / y_size;
	int width = (pos2.x - pos1.x )/ x_size;

	// Joins a neighbor
	auto jn = [&width, &height, &grid](Node* node, const int& x, const int& y) {
		if (x >= 0 && x < width && y >= 0 && y < height)
			node->addNeighbor(grid.getAt(x + y * width));
	};
	// Joins the nodes
	auto joinNeighbors = [&jn](Node* node, const int& x, const int& y) {
		jn(node, x - 1, y + 1); jn(node, x, y + 1); jn(node, x + 1, y + 1);
		jn(node, x - 1, y); 					jn(node, x + 1, y);
		jn(node, x - 1, y - 1); jn(node, x, y - 1); jn(node, x + 1, y - 1);
	};
	// Joints all the neighbors
	for (int y = 0; y < height; y++)
		for (int x = 0; x < width; x++)
			joinNeighbors(grid.getAt(x + y * width), x, y);

	return grid;
}

Node* getRelativeNode(const List<Node*>& grid, const geometry_msgs::Pose2D& pose) {
	// Gets the min distance
	float distance = -1.0f;
	float min_distance = -1.0f;
	Node* min_node;
	Node* current;

	Vector2i pose_pos = Vector2i(pose.x, pose.y);
	for (int i = 1; i < grid.length(); i++) {
		current = grid.getAt(i);
		distance = current->getPosition().getDistance(pose_pos);
		if (min_distance < 0 || distance < min_distance) {
			min_distance = distance;
			min_node = current;
		}
	}

	return min_node;
}

/**
 * Transforms nodes into Pose2D
 **/
graphical_client::Pose2D_Array nodesToPose2D(const List<Node*>& nodes) {
	// Transforms the nodes into poses
	auto res = graphical_client::Pose2D_Array();
	for (int i = 0; i < nodes.length(); i++)
		res.poses.push_back(nodes.getAt(i)->getPosition().toPose2D());

	return res;
}

/**
 * With a given trajectory and position, it calculates the velocity.
 **/
geometry_msgs::Pose2D getVelocity(const geometry_msgs::Pose2D& car,
	const graphical_client::Pose2D_Array& trajectory, Node& goal) {
	return geometry_msgs::Pose2D();
}

geometry_msgs::Pose2D getPosition(const geometry_msgs::Pose2D& velocity) {
	return velocity;
}

void clearPointers(List<Node*> nodes) {
	for (unsigned int i = 0; i < nodes.length(); i++)
		delete nodes.getAt(i);
	nodes.clear();
}


int main(int argc, char **argv)  {

	ros::init(argc, argv, "coche_node");
	ros::NodeHandle nh;
	ROS_INFO_STREAM("coche_node initialized");																									
	ROS_INFO_STREAM(ros::this_node::getName());

	ros::Rate rate(RATE);

	// Bag subscribers
	std::vector<ros::Subscriber> bags_subscribers;
	ros::Subscriber sub;
	for (int i = 0; i < 10; i++) {
		sub = ros::Subscriber();
		sub = nh.subscribe("/b_r" + std::to_string(i), 1000, &getBag);
		bags_subscribers.push_back(sub);
	}
	// Sends position
	ros::Publisher car_position_pub = nh.advertise<geometry_msgs::Pose2D> ("/y_r0", 1);
	// Receives position
	ros::Subscriber car_position_sub = nh.subscribe("/y_r0", 1000, &saveCarPosition);
	// Receives goal
	ros::Subscriber goal_sub = nh.subscribe("/ball", 1000, &getGoalPosition);
	// Prints trajectory
	ros::Publisher trajectory_pub = nh.advertise<graphical_client::Pose2D_Array> ("/trajectory", 1);

	//std_msgs::Float32 msg;
	//float m;

	List<Node*> nodes;
	geometry_msgs::Pose2D velocity;
	geometry_msgs::Pose2D position;
	graphical_client::Pose2D_Array trajectory;

	// Creates the grid
	auto pos1 = Vector2i(0, -2500);
	auto pos2 = Vector2i(3500, 2500);
	int x_size = 500;
	int y_size = 500;
	List<Node*> grid;
	Node* car = nullptr;
	Node* goal = nullptr;


	bool TEST = false;

	while (ros::ok())
	{
		ros::spinOnce();
		rate.sleep();

		// Waits until it has all the bags
		if (BAGS.length() < 10)
			std::cout << BAGS.length() << std::endl;
		// Creates the grid and obtains the new goal and car
		else if (car == nullptr || goal == nullptr) {
			grid = createGrid(BAGS, pos1, pos2, x_size, y_size);
			goal = getRelativeNode(grid, GOAL);
			car = getRelativeNode(grid, CAR);
			std::cout << CAR.y << std::endl;
			std::cout << car->getPosition().y << std::endl;
		}
		else if(!TEST) {
			// Gets the trajectory
			nodes = A_Star::getPath(grid, *car, *goal);
			trajectory = nodesToPose2D(nodes);
			std::cout << "Calculated." << std::endl;
			// Moves the car
			//velocity = getVelocity(CAR, trajectory, *goal);
			// Sets new position (only for testing)
			//position = getPosition(velocity);
			//car_position_pub.publish(position);
			// Prints the trajectory
			trajectory_pub.publish(trajectory);
			//clearPointers(nodes);
			TEST = true;
		}
	}

    return 0;
}