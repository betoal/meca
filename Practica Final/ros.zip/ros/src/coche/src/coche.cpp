#include <ros/ros.h>

#include <iostream>
#include <geometry_msgs/Pose2D.h>
#include <graphical_client/Pose2D_Array.h>

#define RATE 2

// Our goal
geometry_msgs::Pose2D goal;

void goal_position(const geometry_msgs::Pose2D& pose) {
	goal = pose;
}

// Our bags
std::vector<geometry_msgs::Pose2D> bags;

char current_bag = 0;
void get_bag(const geometry_msgs::Pose2D& pose) {
	if (bags.size() <= current_bag)
		bags.push_back(pose);
	if (current_bag > 9) {
		current_bag = -1;
	}
	current_bag++;
}

// Car position
geometry_msgs::Pose2D car;

void save_car_position(const geometry_msgs::Pose2D& pos) {
	car = pos;
}


graphical_client::Pose2D_Array get_trajectory(const geometry_msgs::Pose2D& car, 
	const std::vector<geometry_msgs::Pose2D>& bags, const geometry_msgs::Pose2D& goal) {

	auto nodes = graphical_client::Pose2D_Array();
	nodes.poses.push_back(car);
	nodes.poses.push_back(goal);
	return nodes;
}


// Trajectory to the end
geometry_msgs::Pose2D get_velocity(const geometry_msgs::Pose2D& car,
	const graphical_client::Pose2D_Array& trajectory, const geometry_msgs::Pose2D& goal) {
	return goal;
}

geometry_msgs::Pose2D get_position(const geometry_msgs::Pose2D& velocity) {
	return velocity;
}


int main(int argc, char **argv)  {

	ros::init(argc,argv,"coche_node");
	ros::NodeHandle nh;
	ROS_INFO_STREAM("coche_node initialized");																																							
	ROS_INFO_STREAM(ros::this_node::getName());

	ros::Rate rate(RATE);

	// Bag subscribers
	std::vector<ros::Subscriber> bags_subscribers;
	ros::Subscriber sub;
	for (int i = 0; i < 10; i++) {
		sub = ros::Subscriber();
		sub = nh.subscribe("/b_r" + std::to_string(i), 1000, &get_bag);
		bags_subscribers.push_back(sub);
	}
	// Sends position
	ros::Publisher car_position_pub = nh.advertise<geometry_msgs::Pose2D> ("/y_r0", 1);
	// Receives position
	ros::Subscriber car_position_sub = nh.subscribe("/y_r0", 1000, &save_car_position);
	// Receives goal
	ros::Subscriber goal_sub = nh.subscribe("/ball", 1000, &goal_position);
	// Prints trajectory
	ros::Publisher trajectory_pub = nh.advertise<graphical_client::Pose2D_Array> ("/trajectory", 1);

	//std_msgs::Float32 msg;
	//float m;

	geometry_msgs::Pose2D velocity;
	geometry_msgs::Pose2D position;
	graphical_client::Pose2D_Array trajectory;

	while (ros::ok())
	{
		ros::spinOnce();
		rate.sleep();

		if (bags.size() < 10) continue;

		// Gets the trajectory
		trajectory = get_trajectory(car, bags, goal);
		// Moves the car
		velocity = get_velocity(car, trajectory, goal);
		// Sets new position (only for testing)
		position = get_position(velocity);
		//car_position_pub.publish(position);
		// Prints the trajectory
		trajectory_pub.publish(trajectory);
	}

    return 0;
}
