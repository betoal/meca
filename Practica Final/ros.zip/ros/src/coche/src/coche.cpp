#include <ros/ros.h>

#include <iostream>
#include <geometry_msgs/Pose2D.h>
#include <graphical_client/Pose2D_Array.h>
#include <math.h>

#define RATE 2

#define BAG_RADIUS 50.0f

/**
 * UTILS
 **/
template <class T> class List {
public:
	List() {}

	void Add(const T& value) {
		m_list.push_back(value);
	}

	T& GetAt(const unsigned int& i) const {
		return m_list.at(i);
	}

	int IndexOf(const T& value) const {
		for (int i = 0; i < m_list.size(); i++)
			if (m_list.at(i) == value)
				return i;
		return -1;
	}

	bool Contains(const T& value) const {
		return IndexOf(value) >= 0;
	}

	void RemoveAt(const unsigned int& i) {
		m_list.erase(m_list.begin() + i);
	}

	void Remove(const T& value) {
		RemoveAt(IndexOf(value));
	}

	void Replace(const unsigned int& i, const T& value) {
		m_list[i] = value;
	}

private:
	std::vector<T> m_list;
};

template <class T, class U> class Map {
public:
	Map() {}

	void Set(const T& key, const U& value) {
		int i = m_keys.IndexOf(key);
		if (i < 0) {
			m_keys.Add(key);
			m_values.Add(value);
		}
		else
			m_values.Replace(i, value);
	}

	U& Get(const T& key) const {
		return m_values.GetAt(m_keys.IndexOf(key));
	}

	void Remove(const T& key) {
		int i = m_keys.IndexOf(key);
		if (i >= 0) {
			m_keys.RemoveAt(i);
			m_values.RemoveAt(i);
		}
	}

private:
	List<T> m_keys;
	List<U> m_values;
};


class Vector2i {
public:
	Vector2i(const int& x, const int& y) : x(x), y(y) {}
	Vector2i() : Vector2i(0, 0) {}

	friend bool operator==(const Vector2i& left, const Vector2i& right) {
		return left.x == right.x && left.y == right.y;
	}

public:
	int x;
	int y;
};



class Node {
public:
	Node(const Vector2i& value, const float& cost) : m_value(value), m_cost(cost) {}

	const Vector2i& GetValue() const {
		return m_value;
	}

	const float& GetCost() const {
		return m_cost;
	}

	void AddNeighbor(Node& neighbor) {
		m_neighbors.push_back(&neighbor);
	}

	const std::vector<Node*>& GetNeighbors() const {
		return m_neighbors;
	}
	
	friend bool operator==(const Node& left, const Node& right) {
		return left.m_value == right.m_value && left.m_cost == right.m_cost;
	}

private:
	Vector2i m_value;
	float m_cost;
	std::vector<Node*> m_neighbors;
};








// A*
std::vector<Node*> A_Star_RebuildPath(const std::vector<Node*>& from, const Node& current) {
	//auto current = path;
	return from;
}

float A_Star_Distance(const Node& start, const Node& goal) {
	const Vector2i& s = start.GetValue();
	const Vector2i& g = goal.GetValue();
	return sqrt(pow(g.x - s.x, 2) + pow(g.y - s.y, 2));
}

float A_Star_Heuristic(const Node& start, const Node& goal) {
	return A_Star_Distance(start, goal) + start.GetCost();
}

/*
void A_Star(const List<Node>& nodes, const Node& start, const Node& goal) {
	// The set of nodes already evaluated
    auto closed_set = List<Node>();

    // The set of currently discovered nodes that are not evaluated yet.
    // Initially, only the start node is known.
    auto open_set = List<Node>();
    open_set.Add(start);

    // For each node, which node it can most efficiently be reached from.
    // If a node can be reached from many nodes, cameFrom will eventually contain the
    // most efficient previous step.
    auto came_from = Map<Node&, Node&>();

    // For each node, the cost of getting from the start node to that node.
    auto g_score = Map<Node&, float>();
    Node* n;
    for (int i = 1; i < nodes.size(); i++) {
    	n = &nodes.at(i);
    	g_score.Set(n, A_Star_Distance(n, start));
    }
    // The cost of going from start to start is zero.
    g_score.set(start, 0.0f);

    // For each node, the total cost of getting from the start node to the goal
    // by passing by that node. That value is partly known, partly heuristic.
    auto f_score = Map<Node&, float>();
    for (int i = 1; i < nodes.size(); i++)
    	f_score.Set(nodes.at(i), 2 << 16);

    // For the first node, that value is completely heuristic.
    f_score.set(start, A_Star_Heuristic(start, goal));

    Node current;
    while (open_set.size()) {
    	current = open_set.
        current := the node in openSet having the lowest fScore[] value
        if (current == goal)
            return A_Star_RebuildPath(cameFrom, current);

        openSet.Remove(current)
        closedSet.Add(current)

        for(Node& neighbor : current.GetNeighbors())
            if neighbor in closedSet
                continue;		// Ignore the neighbor which is already evaluated.

            // The distance from start to a neighbor
            tentative_gScore := gScore[current] + A_Star_Distance(current, neighbor);

            if neighbor not in openSet	// Discover a new node
                openSet.push_back(neighbor)
            else if tentative_gScore >= gScore[neighbor]
                continue;

            // This path is the best until now. Record it!
            cameFrom[neighbor] := current
            gScore[neighbor] := tentative_gScore
            fScore[neighbor] := gScore[neighbor] + heuristic_cost_estimate(neighbor, goal)
    }
}
*/







/**
 * THE MAIN SCRIPT
 **/
geometry_msgs::Pose2D goal;

void GoalPosition(const geometry_msgs::Pose2D& pose) {
	goal = pose;
}

// Our bags
std::vector<geometry_msgs::Pose2D> bags;

char current_bag = 0;
void GetBag(const geometry_msgs::Pose2D& pose) {
	if (bags.size() <= current_bag)
		bags.push_back(pose);
	if (current_bag > 9) {
		current_bag = -1;
	}
	current_bag++;
}

// Car position
geometry_msgs::Pose2D car;

void SaveCarPosition(const geometry_msgs::Pose2D& pos) {
	car = pos;
}

bool IsNodeInBag(const Vector2i& pos, const std::vector<geometry_msgs::Pose2D>& bags) {
	for (geometry_msgs::Pose2D pose : bags) {
		if (sqrt(pow(pose.x - pos.x, 2) + pow(pose.y - pos.x, 2)) <= BAG_RADIUS)
			return true;
	}
	return false;
}


/**
 * Gets the trajectory to the goal.
 **/
graphical_client::Pose2D_Array GetTrajectory(const geometry_msgs::Pose2D& car, 
	const std::vector<geometry_msgs::Pose2D>& bags, const geometry_msgs::Pose2D& goal) {
	// The grid proportions
	auto pos1 = Vector2i(0, -2500);
	auto pos2 = Vector2i(3500, 2500);
	int x_size = 200;
	int y_size = 200;
	// Divides the grid
	auto grid = List<Node>();
	auto node = Node(pos1, 0.0f);
	float cost;
	Vector2i pos = Vector2i();
	// And create the grid
	for (int y = pos1.y; y < pos2.y; y += y_size)
		for (int x = pos1.x; x < pos2.x; x += x_size) {
			pos.x = x;
			pos.y = y;
			cost = IsNodeInBag(pos, bags) ? 100.0f : 0.0f;
			node = Node(pos, cost);
			grid.Add(node);
		}
	auto trajectory = graphical_client::Pose2D_Array();
	auto pose = geometry_msgs::Pose2D();
	return trajectory;
}


/**
 * With a given trajectory and position, it calculates the velocity.
 **/
geometry_msgs::Pose2D GetVelocity(const geometry_msgs::Pose2D& car,
	const graphical_client::Pose2D_Array& trajectory, const geometry_msgs::Pose2D& goal) {
	return goal;
}

geometry_msgs::Pose2D GetPosition(const geometry_msgs::Pose2D& velocity) {
	return velocity;
}


int main(int argc, char **argv)  {

	ros::init(argc,argv,"coche_node");
	ros::NodeHandle nh;
	ROS_INFO_STREAM("coche_node initialized");																																							
	ROS_INFO_STREAM(ros::this_node::getName());

	ros::Rate rate(RATE);

	// Bag subscribers
	std::vector<ros::Subscriber> bags_subscribers;
	ros::Subscriber sub;
	for (int i = 0; i < 10; i++) {
		sub = ros::Subscriber();
		sub = nh.subscribe("/b_r" + std::to_string(i), 1000, &GetBag);
		bags_subscribers.push_back(sub);
	}
	// Sends position
	ros::Publisher car_position_pub = nh.advertise<geometry_msgs::Pose2D> ("/y_r0", 1);
	// Receives position
	ros::Subscriber car_position_sub = nh.subscribe("/y_r0", 1000, &SaveCarPosition);
	// Receives goal
	ros::Subscriber goal_sub = nh.subscribe("/ball", 1000, &GoalPosition);
	// Prints trajectory
	ros::Publisher trajectory_pub = nh.advertise<graphical_client::Pose2D_Array> ("/trajectory", 1);

	//std_msgs::Float32 msg;
	//float m;

	geometry_msgs::Pose2D velocity;
	geometry_msgs::Pose2D position;
	graphical_client::Pose2D_Array trajectory;

	while (ros::ok())
	{
		ros::spinOnce();
		rate.sleep();

		if (bags.size() < 10) continue;

		// Gets the trajectory
		trajectory = GetTrajectory(car, bags, goal);
		// Moves the car
		velocity = GetVelocity(car, trajectory, goal);
		// Sets new position (only for testing)
		position = GetPosition(velocity);
		//car_position_pub.publish(position);
		// Prints the trajectory
		trajectory_pub.publish(trajectory);
	}

    return 0;
}