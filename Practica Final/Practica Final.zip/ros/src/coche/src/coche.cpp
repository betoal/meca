#include <ros/ros.h>

#include <iostream>
#include <string>
#include <geometry_msgs/Pose2D.h>
#include <graphical_client/Pose2D_Array.h>
#include <math.h>

#define DEBUG 1

#define RATE 3

#define FORCE 0.5f
#define PRECISION 250.0f

#define BAG_COUNT 10
#define BAG_RADIUS 250.0f


/**
 * UTILS
 **/


template <class T> class List {
public:
	List() {}

	~List() {
		clear();
	}

	void add(const T& value) {
		m_list.push_back(value);
	}

	void addAt(const T& value, const unsigned int& i) {
		m_list.insert(m_list.begin() + i, value);
	}

	void addFirst(const T& value) {
		addAt(value, 0);
	}

	T getAt(const unsigned int& i) const {
		return m_list.at(i);
	}

	int indexOf(const T& value) const {
		for (int i = 0; i < m_list.size(); i++)
			if (m_list.at(i) == value)
				return i;
		return -1;
	}

	bool contains(const T& value) const {
		return indexOf(value) >= 0;
	}

	unsigned int length() const {
		return m_list.size();
	}

	bool isEmpty() const {
		return length() == 0;
	}

	T removeAt(const unsigned int& i) {
		T res = getAt(i);
		m_list.erase(m_list.begin() + i);
		return res;
	}

	void removeFirst() {
		return removeAt(0);
	}

	void remove(const T& value) {
		int i = indexOf(value);
		if (i >= 0) removeAt(i);
	}

	void clear() {
		for (unsigned int i = 0; i < length(); i++)
			removeAt(i);
	}

	void replace(const unsigned int& i, const T& value) {
		m_list[i] = value;
	}

private:
	std::vector<T> m_list;
};




template <class T, class U> class Map {
public:
	Map() {}

	unsigned int length() const {
		return m_keys.length();
	}

	void set(const T& key, const U& value) {
		int i = m_keys.indexOf(key);
		if (i < 0) {
			m_keys.add(key);
			m_values.add(value);
		}
		else
			m_values.replace(i, value);
	}

	U get(const T& key) const {
		return m_values.getAt(m_keys.indexOf(key));
	}

	T getKey(const unsigned int& i) const {
		return m_keys.getAt(i);
	}

	U getValue(const unsigned int& i) const {
		return m_values.getAt(i);
	}

	void remove(const T& key) {
		int i = m_keys.indexOf(key);
		if (i >= 0) {
			m_keys.removeAt(i);
			m_values.removeAt(i);
		}
	}

private:
	List<T> m_keys;
	List<U> m_values;
};





class Vector2i {
public:
	Vector2i(const int& x, const int& y) : x(x), y(y) {}
	Vector2i(const geometry_msgs::Pose2D& pose) : Vector2i(pose.x, pose.y) {}
	Vector2i() : Vector2i(0, 0) {}

	float getDistance(const Vector2i& other) const {
		return sqrt((x - other.x) * (x - other.x) + (y - other.y) * (y - other.y));
	}

	geometry_msgs::Pose2D toPose2D() const {
		geometry_msgs::Pose2D res;
		res.x = x;
		res.y = y;
		res.theta = 0.0f;
		return res;
	}

	std::string toString() const {
		return std::string("(").append(std::to_string(x)).append(", ")
				.append(std::to_string(y)).append(")");
	}

	friend bool operator==(const Vector2i& left, const Vector2i& right) {
		return left.x == right.x && left.y == right.y;
	}

public:
	int x;
	int y;
};


class Node {
public:
	Node() : Node(Vector2i()) {}
	Node(const Vector2i& position) : Node(position, 0.0f, 0.0f) {}
	Node(const Vector2i& position, const float& g, const float& h) 
		: m_position(position), g(g), h(h) {}

	const Vector2i& getPosition() const {
		return m_position;
	}

	float getF() const {
		return g + h;
	}

	float getDistance(const Node& other) const {
		return m_position.getDistance(other.getPosition());
	}

	void addNeighbor(Node* neighbor) {
		m_neighbors.add(neighbor);
	}

	const List<Node*>& getNeighbors() const {
		return m_neighbors;
	}


	std::string toString() {
		return std::string("[").append(m_position.toString())
				.append(", ").append(std::to_string(getF())).append("]");
	}

	friend bool operator==(const Node& left, const Node& right) {
		return left.getPosition() == right.getPosition() 
				&& left.g == right.g && left.h == right.h;
	}

public:
	Node* pathParent;
	float g;
	float h;

private:
	Vector2i m_position;
	List<Node*> m_neighbors;
};




/**
 * Bags.
 **/

List<geometry_msgs::Pose2D> BAGS;

// Just gets the bags once
char current_bag = 0;
void getBag(const geometry_msgs::Pose2D& pose) {
	if (BAGS.length() <= current_bag)
		BAGS.add(pose);
	if (current_bag > BAG_COUNT - 1) {
		current_bag = -1;
	}
	current_bag++;
}

/**
 * Checks if a node is touching a bag.
 **/
bool isNodeInBag(const Node* node, const List<geometry_msgs::Pose2D>& bags, const float& radius) {
	const Vector2i& pos = node->getPosition();
	for (unsigned int i = 0; i < BAGS.length(); i++) {
		geometry_msgs::Pose2D&& pose = BAGS.getAt(i);
		if (sqrt(pow(pose.x - pos.x, 2) + pow(pose.y - pos.y, 2)) <= radius)
			return true;
	}
	return false;
}

namespace A_Star {

    /**
     * Construct the path, not including the start node.
     */
	const List<Node*> constructPath(Node* node) {
		auto path = List<Node*>();
		while (node->pathParent != nullptr) {
			path.addFirst(node);
			node = node->pathParent;
		}
		return path;
	}

	Node* getLowestFNode(const List<Node*>& list) {
		Node* min = list.getAt(0);
		Node* n;
		for (unsigned int i = 1; i < list.length(); i++) {
			n = list.getAt(i);
			if (n->getF() < min->getF())
				min = n;
		}
		return min;
	}

	/*
	 * Find the path from the start node to the end node. A list
	 * of Nodes is returned.
	 */
	List<Node*> findPath(Node* start, Node* goal) {
		auto open_list = List<Node*>();
		auto closed_list = List<Node*>();

		start->g = 0;
		start->h = start->getDistance(*goal);
		start->pathParent = nullptr;
		open_list.add(start);

		Node* node;
		Node* neighbor;
		float g, h;
		bool is_open, is_closed;

		while (!open_list.isEmpty()) {
			node = getLowestFNode(open_list);
			open_list.remove(node);

			// The goal was found
			if (node == goal)
				return constructPath(goal);

			auto neighbors = node->getNeighbors();
			// Iterates through neighbors
			for (unsigned int i = 0; i < neighbors.length(); i++) {
				neighbor = neighbors.getAt(i);
				g = node->g + node->getDistance(*neighbor);
				is_open = open_list.contains(neighbor);
				is_closed = closed_list.contains(neighbor);

        		// Check if the neighbor node has not been
        		// traversed or if a shorter path to this
        		// neighbor node is found.
				if (!(is_open || is_closed) || g < neighbor->g) {
					neighbor->pathParent = node;
					neighbor->g = g;
					neighbor->h = neighbor->getDistance(*goal);
					if (isNodeInBag(neighbor, BAGS, BAG_RADIUS))
						neighbor->h *= neighbor->h;
					if (is_closed)
						closed_list.remove(neighbor);
					if (!is_open)
						open_list.add(neighbor);
				}
			}
			closed_list.add(node);
		}
		return List<Node*>();
	}
}





/**
 * THE MAIN SCRIPT
 **/

// The goal position
geometry_msgs::Pose2D GOAL;

void getGoalPosition(const geometry_msgs::Pose2D& pose) {
	GOAL = pose;
}

// Car position
geometry_msgs::Pose2D CAR;

void saveCarPosition(const geometry_msgs::Pose2D& pos) {
	CAR = pos;
}


/**
 * Creates the public grid.
**/
List<Node*> createGrid(const List<geometry_msgs::Pose2D>& bags, const Vector2i& pos1,
	const Vector2i& pos2, const int& x_size, const int& y_size) {
	// And create the grid
	auto grid = List<Node*>();
	auto pos = Vector2i();
	Node* node;
	for (int y = pos1.y; y < pos2.y; y += y_size)
		for (int x = pos1.x; x < pos2.x; x += x_size) {
			pos.x = x;
			pos.y = y;
			grid.add(new Node(pos));
		}

	int height = (pos2.y - pos1.y) / y_size;
	int width = (pos2.x - pos1.x ) / x_size;

	// Joins a Neighbor
	auto jc = [&width, &height, &grid](Node* node, const int& x, const int& y) {
		if (x >= 0 && x < width && y >= 0 && y < height)
			node->addNeighbor(grid.getAt(x + y * width));
	};
	// Joins the nodes
	auto joinNeighbors = [&jc](Node* node, const int& x, const int& y) {
		jc(node, x - 1, y + 1); jc(node, x, y + 1); jc(node, x + 1, y + 1);
		jc(node, x - 1, y); 					    jc(node, x + 1, y);
		jc(node, x - 1, y - 1); jc(node, x, y - 1); jc(node, x + 1, y - 1);
	};
	// Joins all the neighbors
	for (int y = 0; y < height; y++)
		for (int x = 0; x < width; x++)
			joinNeighbors(grid.getAt(x + y * width), x, y);

	return grid;
}

Node* getClosestNode(const List<Node*>& grid, const Node* node) {
	Node* curr = grid.getAt(0);
	float curr_distance = curr->getDistance(*node);
	float other_distance;
	Node* n;
	for (unsigned int i = 1; i < grid.length(); i++) {
		n = grid.getAt(i);
		other_distance = n->getDistance(*node);
		if (other_distance < curr_distance) {
			curr_distance = other_distance;
			curr = n;
		}
	}
	return curr;
}

/**
 * Calculates the costs.
 **/
void calculateCosts(const List<Node*>& grid, const List<geometry_msgs::Pose2D>& bags,
					 const float& radius, Node* start, Node* goal) {
	Node* curr;
	for (unsigned int i = 0; i < grid.length(); i++) {
		curr = grid.getAt(i);
		curr->g = curr->getDistance(*start);
		curr->h = curr->getDistance(*goal);
	}
}


/**
 * Transforms nodes into Pose2D
 **/
graphical_client::Pose2D_Array nodesToPose2D(const List<Node*>& nodes) {
	// Transforms the nodes into poses
	auto res = graphical_client::Pose2D_Array();
	for (int i = 0; i < nodes.length(); i++)
		res.poses.push_back(nodes.getAt(i)->getPosition().toPose2D());

	return res;
}

/**
 * Transforms radians.
 **/
float transformRadians(float radian) {
	const float pi_2 = 2 * M_PI;
	// Changes sign
	while (radian < 0)
		radian += pi_2;

	// Unitary circle
	while (radian > pi_2)
		radian -= pi_2;

	return radian;
}

/**
 * Checks if an angle is between two.
 **/
bool isRadianBetween(float value, float start, float end) {
	end = transformRadians(end - start);
	value = transformRadians(value - start);
	return value <= end;
}

float radiansDistance(const float& start, const float& end) {
	return transformRadians(end - start);
}



/**
 * With a given trajectory and position, it calculates the velocity.
 **/
geometry_msgs::Pose2D getVelocity(List<Node*>& trajectory, const geometry_msgs::Pose2D& car) {

	Node n_car = Node(car);

	Node* closest;
	// Removes the closest if it's too close (except the goal).
	while ((closest = getClosestNode(trajectory, &n_car))->getDistance(n_car) <= PRECISION
				&& trajectory.length() > 1)
		trajectory.remove(closest);

	Vector2i pos = closest->getPosition();
	float theta = transformRadians(-car.theta + M_PI / 2);
	float dy = pos.y - car.y;
	float dx = pos.x - car.x;
	float distance = sqrt(dy * dy + dx * dx);
	float phi = transformRadians(atan2(dy, dx));
	float m_phi = transformRadians(phi - M_PI);
	
	//float force = transformRadians(m_phi + M_PI2 - theta) / (2 * M_PI);
	float force, right_force, left_force;

	#if DEBUG
	std::cout << "THETA: " << theta << std::endl;
	std::cout << "PHI:   " << phi << std::endl;
	std::cout << "M_PHI: " << m_phi << std::endl;
	#endif

	// Left quadrants 
	//   theta > phi && theta < m_phi

	if (isRadianBetween(theta, phi, m_phi)) {
		std::cout << "LEFT";
		left_force = 1.0f;
		// First quadrant
		//theta < transformRadians(phi - M_PI / 2)
		if (isRadianBetween(theta, phi, phi + M_PI / 2)) {
			std::cout << " FIRST" << std::endl;
			force = 2 * radiansDistance(phi, theta) / M_PI;
			right_force = 1.0f - force;
		}
		// Second quadrant
		else {
			std::cout << " SECOND" << std::endl;
			force = 2 * radiansDistance(m_phi, theta) / M_PI;
			right_force = -1.0f + force;
		}
	}
	// Lower quadrant
	else {
		std::cout << "RIGHT";
		right_force = 1.0f;
		// First quadrant
		if (isRadianBetween(theta, phi - M_PI / 2, phi)) {
			std::cout << " FIRST" << std::endl;
			force = 2 * radiansDistance(theta, phi) / M_PI;
			left_force = 1.0f - force;
		}
		// Second quadrant
		else {
			std::cout << " SECOND" << std::endl;
			force = 2 * radiansDistance(m_phi, theta) / M_PI;
			left_force = -1.0f + force;
		}
	}

	std::cout << "FORCE: " << force << std::endl;

	left_force *= FORCE;
	right_force *= FORCE;

	auto res = geometry_msgs::Pose2D();
	res.x = left_force;
	res.y = right_force;
	return res;
}




int main(int argc, char **argv)  {

	ros::init(argc, argv, "coche_node");
	ros::NodeHandle nh;
	ROS_INFO_STREAM("coche_node initialized");																									
	ROS_INFO_STREAM(ros::this_node::getName());

	ros::Rate rate(RATE);

	// Bag subscribers
	std::vector<ros::Subscriber> bags_subscribers;
	ros::Subscriber sub;
	for (int i = 0; i < 10; i++) {
		sub = ros::Subscriber();
		sub = nh.subscribe("/b_r" + std::to_string(i), 1000, &getBag);
		bags_subscribers.push_back(sub);
	}
	// Sends position
	ros::Publisher car_position_pub = nh.advertise<geometry_msgs::Pose2D> ("/y_r0", 1);
	// Receives position
	ros::Subscriber car_position_sub = nh.subscribe("/y_r0", 1000, &saveCarPosition);
	// Receives goal
	ros::Subscriber goal_sub = nh.subscribe("/ball", 1000, &getGoalPosition);
	// Prints trajectory
	ros::Publisher trajectory_pub = nh.advertise<graphical_client::Pose2D_Array> ("/trajectory", 1);
	// Publishes velocity
	ros::Publisher velocity_pub = nh.advertise<geometry_msgs::Pose2D> ("/velocity", 1);

	//std_msgs::Float32 msg;
	//float m;

	List<Node*> nodes;
	geometry_msgs::Pose2D velocity;
	geometry_msgs::Pose2D position;
	graphical_client::Pose2D_Array trajectory;

	// Creates the grid
	auto pos1 = Vector2i(0, -2500);
	auto pos2 = Vector2i(3500, 2500);
	int x_size = 250;
	int y_size = 250;
	List<Node*> grid;
	Node* car;
	Node* goal;
	bool done = false;


	bool TEST = false;

	while (ros::ok())
	{
		ros::spinOnce();
		rate.sleep();

		// Waits until it has all the bags
		if (BAGS.length() < BAG_COUNT)
			std::cout << BAGS.length() << std::endl;
		// Creates the grid and obtains the new goal and car
		else if (!done) {
			grid = createGrid(BAGS, pos1, pos2, x_size, y_size);
			goal = new Node(GOAL);
			// Joins the start and end to the grid.
			Node* aux = getClosestNode(grid, goal);
			goal->addNeighbor(aux);
			aux->addNeighbor(goal);
			car = new Node(CAR);
			aux = getClosestNode(grid, car);
			car->addNeighbor(aux);
			aux->addNeighbor(car);
			// And adds to the grid
			grid.add(car);
			grid.add(goal);
			calculateCosts(grid, BAGS, BAG_RADIUS, car, goal);
			// Gets the trajectory
			nodes = A_Star::findPath(car, goal);
			done = true;
		}
		else {
			// Moves the car
			//float angle = -M_PI / 16;
			//CAR.theta = M_PI / 2 - angle;
			velocity = getVelocity(nodes, CAR);
			std::cout << velocity.x << ", " << velocity.y << std::endl;
			velocity_pub.publish(velocity);

			// Only for debbuging
			#if DEBUG
			std::cout << "Car theta: " << CAR.theta << std::endl;
			std::cout << "--------------" << std::endl;
			trajectory = nodesToPose2D(nodes);
			trajectory_pub.publish(trajectory);
			#endif
		}
	}

    return 0;
}