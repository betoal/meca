^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package rosserial_vex_cortex
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
0.8.0 (2018-10-11)
------------------
* VEX Cortex Usage improvements and VEX V5 Support (`#385 <https://github.com/ros-drivers/rosserial/issues/385>`_)
* Re-attempting rosserial for VEX Cortex (`#380 <https://github.com/ros-drivers/rosserial/issues/380>`_)
* Contributors: CanyonTurtle

0.7.7
-----------------------------
- README fixes
- started tagging versions
- initial was wrong version number, fixed.
